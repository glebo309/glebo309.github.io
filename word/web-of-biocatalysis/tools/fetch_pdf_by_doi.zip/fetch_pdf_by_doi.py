#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ULTIMATE Standalone DOI-to-PDF fetcher using ALL methods from the battle-tested pipeline.

This tool provides an interactive terminal dialog that asks for a DOI as input
and then attempts to find and download the PDF using the COMPLETE 7-method 
PDF acquisition pipeline from pipeline_get-pdf_extract-to-xml.py.

Usage:
    python tools/fetch_pdf_by_doi.py
    
    Or with direct DOI:
    python tools/fetch_pdf_by_doi.py --doi "10.1038/nature12373"
"""

import argparse
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional, Dict, Any

# Add the parent directory to Python path to import local modules
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from tools.pipeline.config import load_config
    from tools.pipeline.storage import Store
    from tools.pipeline.sources import (
        fetch_crossref,
        fetch_semanticscholar,
        fetch_unpaywall,
        best_pdf_url_from_unpaywall,
    )
    from tools.pipeline.grobid_client import grobid_process_pdf
except ImportError as e:
    print(f"Error importing pipeline modules: {e}")
    print("Make sure you're running this from the project root directory")
    sys.exit(1)

# Import the PDF fetching methods from the pipeline
try:
    import requests
    from urllib.parse import urljoin
    from bs4 import BeautifulSoup
except ImportError as e:
    print(f"Missing required dependencies: {e}")
    print("Please install: pip install requests beautifulsoup4")
    sys.exit(1)

# -------- Configuration --------
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = ROOT / "downloads" / "pdfs"
UA_DEFAULT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"

# -------- Helper Functions --------

def normalize_doi(s: str) -> str:
    """Normalize DOI format"""
    s = (s or "").strip()
    s = s.replace("https://doi.org/", "").replace("http://doi.org/", "")
    s = s.replace("doi:", "").replace("DOI:", "")
    return s.strip()

def _session_with_headers() -> requests.Session:
    """Create a session with proper headers"""
    s = requests.Session()
    s.headers.update({"User-Agent": UA_DEFAULT})
    return s

def _validate_pdf_file(path: Path) -> None:
    """Validate that a file is actually a PDF"""
    if not path.exists():
        raise RuntimeError("File does not exist")
    
    if path.stat().st_size < 1024:
        raise RuntimeError("File too small to be a valid PDF")
    
    # Check PDF magic bytes
    with path.open('rb') as f:
        header = f.read(8)
        if not header.startswith(b'%PDF-'):
            # Check if it's HTML
            if b'<html' in header.lower() or b'<!doctype' in header.lower():
                raise RuntimeError("File is HTML, not PDF")
            else:
                raise RuntimeError("File is not a valid PDF")

def merge_meta(cr: Dict[str, Any], s2: Dict[str, Any], oa: Dict[str, Any]) -> Dict[str, Any]:
    """Merge metadata from different sources"""
    # title
    title = ((" ".join(cr.get("title") or [])) or s2.get("title") or "").strip()

    # year
    year = None
    try:
        y = (cr.get("issued") or {}).get("date-parts", [[None]])[0][0]
        year = int(y) if y else None
    except Exception:
        year = s2.get("year")

    # authors
    authors = []
    for a in (cr.get("author") or []):
        nm = " ".join([a.get("given", ""), a.get("family", "")]).strip()
        if nm:
            authors.append(nm)
    if not authors and s2.get("authors"):
        authors = [a.get("name", "").strip() for a in s2.get("authors") if a.get("name")]

    # journal
    journal = ""
    cont = (cr.get("short-container-title") or cr.get("container-title") or [])
    if cont:
        journal = cont[0]
    elif s2.get("journal"):
        j = s2.get("journal")
        journal = j.get("name") if isinstance(j, dict) else str(j)

    oa_pdf, license_ = best_pdf_url_from_unpaywall(oa or {})

    return {
        "title": title,
        "year": year,
        "authors": authors,
        "journal": journal,
        "crossref": cr,
        "semanticscholar": s2,
        "unpaywall": oa,
        "oa_pdf_url": oa_pdf,
        "oa_license": license_,
    }

# -------- PDF Fetching Methods --------

def _try_fetch_oa_pdf(session: requests.Session, url: str, outpath: Path) -> None:
    """Fetch PDF from open access URL"""
    with session.get(url, stream=True, timeout=90, allow_redirects=True) as r:
        r.raise_for_status()
        
        # Check content type
        content_type = r.headers.get('content-type', '').lower()
        if 'html' in content_type:
            raise RuntimeError("URL returned HTML instead of PDF")
        
        with outpath.open("wb") as f:
            for chunk in r.iter_content(chunk_size=1 << 20):
                if chunk:
                    f.write(chunk)
        
        # Validate that it's actually a PDF
        _validate_pdf_file(outpath)

def _try_fetch_semantic_scholar_pdf(doi: str, outpath: Path) -> None:
    """Fetch PDF from Semantic Scholar"""
    url = f"https://api.semanticscholar.org/graph/v1/paper/DOI:{doi}"
    params = {
        'fields': 'title,url,openAccessPdf,externalIds,venue'
    }
    headers = {"User-Agent": UA_DEFAULT}
    
    response = requests.get(url, params=params, headers=headers, timeout=30)
    response.raise_for_status()
    
    data = response.json()
    
    # Check for open access PDF
    open_access_pdf = data.get('openAccessPdf')
    if open_access_pdf and open_access_pdf.get('url'):
        pdf_url = open_access_pdf['url']
        
        session = _session_with_headers()
        with session.get(pdf_url, stream=True, timeout=60, allow_redirects=True) as r:
            r.raise_for_status()
            
            # Check content type
            content_type = r.headers.get('content-type', '').lower()
            if 'html' in content_type:
                raise RuntimeError("URL returned HTML instead of PDF")
            
            with outpath.open("wb") as f:
                for chunk in r.iter_content(chunk_size=1024*1024):
                    if chunk:
                        f.write(chunk)
        
        # Validate that it's actually a PDF
        _validate_pdf_file(outpath)
        return
    
    raise RuntimeError("No PDF found via Semantic Scholar")

def _try_fetch_arxiv_pdf(doi: str, outpath: Path) -> None:
    """Try to get PDF from arXiv if it's an arXiv paper"""
    url = f"https://api.crossref.org/works/{doi}"
    headers = {"User-Agent": UA_DEFAULT}
    
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    
    data = response.json()
    work = data.get('message', {})
    
    # Look for arXiv ID in various fields
    arxiv_id = None
    
    # Check URL
    url_field = work.get('URL', '')
    if 'arxiv.org' in url_field.lower():
        arxiv_id = url_field.split('/')[-1]
    
    # Check alternative-id
    for alt_id in work.get('alternative-id', []):
        if alt_id.startswith('arXiv:'):
            arxiv_id = alt_id.replace('arXiv:', '')
    
    if not arxiv_id:
        raise RuntimeError("Not an arXiv paper")
    
    # Download from arXiv
    arxiv_pdf_url = f"https://arxiv.org/pdf/{arxiv_id}.pdf"
    
    session = _session_with_headers()
    with session.get(arxiv_pdf_url, stream=True, timeout=60, allow_redirects=True) as r:
        r.raise_for_status()
        with outpath.open("wb") as f:
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk:
                    f.write(chunk)
    
    # Validate that it's actually a PDF
    _validate_pdf_file(outpath)

def _try_fetch_crossref_links(doi: str, outpath: Path) -> None:
    """Enhanced Crossref link following"""
    url = f"https://api.crossref.org/works/{doi}"
    headers = {"User-Agent": UA_DEFAULT}
    
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    
    data = response.json()
    work = data.get('message', {})
    
    # Collect potential PDF URLs
    pdf_urls = []
    
    # Check URL field
    if 'URL' in work:
        pdf_urls.append(work['URL'])
    
    # Check link field
    for link in work.get('link', []):
        if link.get('content-type') == 'application/pdf':
            pdf_urls.append(link.get('URL'))
        elif 'pdf' in link.get('URL', '').lower():
            pdf_urls.append(link.get('URL'))
    
    # Try each potential PDF URL
    session = _session_with_headers()
    
    for pdf_url in pdf_urls:
        if not pdf_url:
            continue
            
        try:
            # Follow redirects and check content type
            with session.get(pdf_url, stream=True, timeout=60, allow_redirects=True) as r:
                content_type = r.headers.get('content-type', '').lower()
                
                # Check if it's actually a PDF
                if 'pdf' in content_type or pdf_url.lower().endswith('.pdf'):
                    r.raise_for_status()
                    with outpath.open("wb") as f:
                        for chunk in r.iter_content(chunk_size=1024*1024):
                            if chunk:
                                f.write(chunk)
                    
                    try:
                        _validate_pdf_file(outpath)
                        return  # Valid PDF
                    except RuntimeError:
                        # Not a valid PDF, try next URL
                        continue
        except Exception:
            continue
    
    raise RuntimeError("No accessible PDF found via Crossref")

def _try_fetch_publisher_direct(doi: str, outpath: Path) -> None:
    """Try to get PDF directly from publisher website"""
    doi_url = f"https://doi.org/{doi}"
    session = _session_with_headers()
    
    try:
        # Get the DOI page
        response = session.get(doi_url, timeout=30, allow_redirects=True)
        response.raise_for_status()
        
        # Look for PDF download links in the HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Common PDF link patterns
        pdf_links = []
        
        # Look for links with "pdf" in href
        for link in soup.find_all('a', href=True):
            href = link['href']
            if 'pdf' in href.lower() or 'download' in href.lower():
                # Make absolute URL
                if href.startswith('/'):
                    href = urljoin(response.url, href)
                elif not href.startswith('http'):
                    href = urljoin(response.url, href)
                pdf_links.append(href)
        
        # Try each PDF link
        for pdf_url in pdf_links[:5]:  # Try up to 5 links
            try:
                with session.get(pdf_url, stream=True, timeout=60, allow_redirects=True) as r:
                    content_type = r.headers.get('content-type', '').lower()
                    if 'pdf' in content_type:
                        r.raise_for_status()
                        with outpath.open("wb") as f:
                            for chunk in r.iter_content(chunk_size=1024*1024):
                                if chunk:
                                    f.write(chunk)
                        
                        try:
                            _validate_pdf_file(outpath)
                            return  # Valid PDF
                        except RuntimeError:
                            # Not a valid PDF, try next URL
                            continue
            except Exception:
                continue
                
    except Exception:
        pass
    
    raise RuntimeError("No PDF found via publisher direct access")

def _try_fetch_scihub(doi: str, outpath: Path) -> None:
    """Working SciHub method using manual access"""
    
    # Working SciHub domains (updated list)
    scihub_domains = [
        "https://sci-hub.se",
        "https://sci-hub.ren", 
        "https://sci-hub.st",
        "https://sci-hub.ru",
        "https://sci-hub.wf",
        "https://sci-hub.shop",
        "https://sci-hub.hkvisa.net"
    ]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    for domain in scihub_domains:
        try:
            scihub_url = f"{domain}/{doi}"
            
            session = requests.Session()
            session.headers.update(headers)
            
            response = session.get(scihub_url, timeout=30, allow_redirects=True)
            response.raise_for_status()
            
            # Check if direct PDF
            content_type = response.headers.get('content-type', '').lower()
            if 'pdf' in content_type:
                with outpath.open("wb") as f:
                    f.write(response.content)
                _validate_pdf_file(outpath)
                return
            
            # Parse HTML to find PDF link
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for PDF download links
            pdf_links = []
            
            # Method 1: iframe with PDF
            for iframe in soup.find_all('iframe'):
                src = iframe.get('src', '')
                if src and ('pdf' in src.lower() or src.startswith('//')):
                    if src.startswith('//'):
                        src = 'https:' + src
                    elif src.startswith('/'):
                        src = domain + src
                    pdf_links.append(src)
            
            # Method 2: direct links to PDFs
            for link in soup.find_all('a', href=True):
                href = link['href']
                if 'pdf' in href.lower() or href.endswith('.pdf'):
                    if href.startswith('//'):
                        href = 'https:' + href
                    elif href.startswith('/'):
                        href = domain + href
                    pdf_links.append(href)
            
            # Method 3: button with onclick containing PDF URL
            for button in soup.find_all(['button', 'div'], onclick=True):
                onclick = button.get('onclick', '')
                if 'pdf' in onclick.lower():
                    # Extract URL from onclick
                    import re
                    url_match = re.search(r'https?://[^\s\'"]+\.pdf', onclick)
                    if url_match:
                        pdf_links.append(url_match.group(0))
            
            # Try each PDF link
            for pdf_url in pdf_links:
                try:
                    pdf_response = session.get(pdf_url, timeout=60, allow_redirects=True)
                    pdf_response.raise_for_status()
                    
                    if 'pdf' in pdf_response.headers.get('content-type', '').lower():
                        with outpath.open("wb") as f:
                            f.write(pdf_response.content)
                        _validate_pdf_file(outpath)
                        return
                except Exception:
                    continue
                    
        except Exception:
            continue  # Try next domain
    
    raise RuntimeError("SciHub download failed from all working domains")

def _check_pypaperbot_available() -> bool:
    """Enhanced PyPaperBot availability check"""
    try:
        # First check import
        import PyPaperBot
        
        # Then check command
        import subprocess
        result = subprocess.run([sys.executable, "-m", "PyPaperBot", "--help"], 
                              capture_output=True, text=True, timeout=10)
        return result.returncode == 0
    except Exception:
        return False

def _try_fetch_pypaperbot(doi: str, outpath: Path) -> None:
    """Enhanced PyPaperBot with better error handling"""
    import subprocess
    import tempfile
    import shutil
    
    # Create a temporary download directory for PyPaperBot
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        pypb_download_dir = temp_path / f"pypb_{doi.replace('/', '_').replace('.', '_')}"
        pypb_download_dir.mkdir(exist_ok=True)
        
        try:
            # Run PyPaperBot with the DOI
            cmd = [
                sys.executable, "-m", "PyPaperBot",
                "--doi", doi,
                "--dwn-dir", str(pypb_download_dir),
                "--use-doi-as-filename"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            
            if result.returncode != 0:
                error_msg = result.stderr or result.stdout or "Unknown PyPaperBot error"
                raise RuntimeError(f"PyPaperBot failed (code {result.returncode}): {error_msg}")
            
            # Find the downloaded PDF
            pdf_files = list(pypb_download_dir.glob("*.pdf"))
            if not pdf_files:
                all_files = list(pypb_download_dir.glob("*"))
                if all_files:
                    raise RuntimeError(f"PyPaperBot downloaded files but no PDFs: {[f.name for f in all_files]}")
                else:
                    raise RuntimeError("PyPaperBot completed but no files downloaded")
            
            # Move the first PDF file to our target location
            downloaded_pdf = pdf_files[0]
            _validate_pdf_file(downloaded_pdf)
            
            # Move to target location
            shutil.copy2(str(downloaded_pdf), str(outpath))
            
        except Exception as e:
            raise RuntimeError(f"PyPaperBot error: {e}")

def _try_fetch_libgen(doi: str, outpath: Path) -> None:
    """Try to fetch from Library Genesis"""
    
    libgen_mirrors = [
        "https://libgen.is",
        "https://libgen.rs", 
        "https://libgen.st"
    ]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    for mirror in libgen_mirrors:
        try:
            # Search for the DOI
            search_url = f"{mirror}/scimag/"
            params = {"q": doi}
            
            session = requests.Session()
            session.headers.update(headers)
            
            response = session.get(search_url, params=params, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for download links in the search results
            for link in soup.find_all('a', href=True):
                href = link['href']
                if 'download' in href.lower() or 'get.php' in href:
                    if href.startswith('/'):
                        href = mirror + href
                    
                    try:
                        pdf_response = session.get(href, timeout=60, allow_redirects=True)
                        pdf_response.raise_for_status()
                        
                        content_type = pdf_response.headers.get('content-type', '').lower()
                        if 'pdf' in content_type:
                            with outpath.open("wb") as f:
                                f.write(pdf_response.content)
                            _validate_pdf_file(outpath)
                            return
                    except Exception:
                        continue
                        
        except Exception:
            continue
    
    raise RuntimeError("LibGen download failed from all mirrors")

def _titles_match(a: str, b: str) -> bool:
    """Check if two titles match (from the original pipeline)"""
    a, b = (a or "").strip().lower(), (b or "").strip().lower()
    if not a or not b:
        return False
    if a == b:
        return True
    # Prefix match
    if a.startswith(b[:25]) or b.startswith(a[:25]):
        return True
    # Token-based Jaccard similarity
    def toks(s: str) -> set:
        import re
        return set(re.sub(r"[^\w\s]", "", s).split())
    ta, tb = toks(a), toks(b)
    if not ta or not tb:
        return False
    inter = len(ta & tb)
    uni = len(ta | tb)
    sim = (inter / uni) if uni else 0.0
    return sim >= 0.6

def download_pdf_with_fallbacks(doi: str, output_path: Path) -> bool:
    """
    ULTIMATE PDF download using the COMPLETE 7-method system from pipeline_get-pdf_extract-to-xml.py:
    1. Open Access (Unpaywall) - Free, legal, fast + ALL oa_locations fallback
    2. Semantic Scholar - Academic repository + title-based fallback
    3. Publisher Direct - Often fastest when available  
    4. PyPaperBot - Multi-source aggregator, good success rate
    5. SciHub - Reliable fallback (FIXED with multiple domains!)
    6. arXiv - Preprint server (specialized)
    7. Crossref - Last resort backup
    """
    session = _session_with_headers()
    tmp_pdf = Path(tempfile.mkstemp(suffix=".pdf")[1])
    tried = []
    
    print(f"🔍 Searching for PDF: {doi}")
    
    # First, gather metadata
    print("📊 Gathering metadata...")
    cr = fetch_crossref(doi)
    s2 = fetch_semanticscholar(doi)
    oa = fetch_unpaywall(doi, "research@example.com")  # Use a placeholder email
    meta = merge_meta(cr, s2, oa)
    
    if meta.get("title"):
        print(f"📄 Found paper: {meta['title']}")
        if meta.get("year"):
            print(f"📅 Year: {meta['year']}")
        if meta.get("journal"):
            print(f"📖 Journal: {meta['journal']}")
    
    # Add small delay to be respectful to APIs
    time.sleep(0.5)

    # 1) Open Access (Unpaywall) - ENHANCED with ALL oa_locations
    if doi:
        try:
            print("🌐 Trying Open Access (Unpaywall)...")
            oa_url = meta.get("oa_pdf_url") or ""
            if not oa_url:
                # Try to derive from Unpaywall data
                oa_data = meta.get("unpaywall") or {}
                oa_url, _lic = best_pdf_url_from_unpaywall(oa_data or {})
            if oa_url:
                _try_fetch_oa_pdf(session, oa_url, tmp_pdf)
                print("✅ Open Access PDF downloaded successfully!")
                tmp_pdf.rename(output_path)
                return True
            else:
                # NEW: iterate all oa_locations as a broader fallback
                oa_data = meta.get("unpaywall") or {}
                got = False
                for loc in (oa_data.get("oa_locations") or []):
                    cand = loc.get("url_for_pdf") or loc.get("url") or ""
                    if not cand:
                        continue
                    try:
                        _try_fetch_oa_pdf(session, cand, tmp_pdf)
                        print(f"✅ OA location PDF fetched: {cand}")
                        tmp_pdf.rename(output_path)
                        return True
                    except Exception:
                        continue
                if not got:
                    raise RuntimeError("No OA URL available")
        except Exception as e:
            tried.append(f"unpaywall:{type(e).__name__}")
            print(f"❌ Open Access failed: {e}")

    # 2) Semantic Scholar - ENHANCED with title-based fallback
    if doi:
        try:
            print("🎓 Trying Semantic Scholar...")
            _try_fetch_semantic_scholar_pdf(doi, tmp_pdf)
            print("✅ Semantic Scholar PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"semanticscholar:{type(e).__name__}")
            print(f"❌ Semantic Scholar failed: {e}")

        # NEW: Title-based S2 OA PDF fallback even when DOI is known
        try:
            title = (meta.get("title") or "").strip()
            year = meta.get("year")
            if title:
                print("🎓 Trying Semantic Scholar title-based fallback...")
                s2_url = "https://api.semanticscholar.org/graph/v1/paper/search"
                params = {"query": f"{title} {year}" if year else title, "limit": 10, "fields": "title,openAccessPdf,year"}
                r = requests.get(s2_url, params=params, headers={"User-Agent": UA_DEFAULT}, timeout=20)
                if r.ok:
                    dd = r.json()
                    for p in (dd.get('data') or []):
                        if not _titles_match(title, p.get('title', '')):
                            continue
                        if year and p.get('year') and abs(int(p.get('year')) - int(year)) > 2:
                            continue
                        oap = p.get('openAccessPdf') or {}
                        pdf_url = oap.get('url')
                        if not pdf_url:
                            continue
                        with session.get(pdf_url, stream=True, timeout=60, allow_redirects=True) as r2:
                            r2.raise_for_status()
                            with tmp_pdf.open("wb") as f:
                                for chunk in r2.iter_content(chunk_size=1 << 20):
                                    if chunk:
                                        f.write(chunk)
                        if tmp_pdf.stat().st_size > 1024:
                            print("✅ S2 title-based OA PDF fetched!")
                            tmp_pdf.rename(output_path)
                            return True
        except Exception as e:
            print(f"❌ S2 title-based fallback failed: {e}")

    # 3) Publisher Direct - Often fastest when available
    if doi:
        try:
            print("🏢 Trying publisher direct access...")
            _try_fetch_publisher_direct(doi, tmp_pdf)
            print("✅ Publisher direct PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"publisher:{type(e).__name__}")
            print(f"❌ Publisher direct failed: {e}")

    # 4) PyPaperBot - Multi-source aggregator, good success rate
    if doi and _check_pypaperbot_available():
        try:
            print("🤖 Trying PyPaperBot (multi-source aggregator)...")
            _try_fetch_pypaperbot(doi, tmp_pdf)
            print("✅ PyPaperBot PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"pypaperbot:{type(e).__name__}")
            print(f"❌ PyPaperBot failed: {e}")
    elif doi:
        print("⚠️  PyPaperBot not available (install with: pip install PyPaperBot)")

    # 5) SciHub - RELIABLE FALLBACK (FIXED with multiple domains!)
    if doi:
        try:
            print("🏴‍☠️ Trying SciHub (fixed method)...")
            _try_fetch_scihub(doi, tmp_pdf)
            print("✅ SciHub PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"scihub:{type(e).__name__}")
            print(f"❌ SciHub failed: {e}")

    # 6) arXiv - SPECIALIZED FOR PREPRINTS
    if doi:
        try:
            print("📚 Checking arXiv...")
            _try_fetch_arxiv_pdf(doi, tmp_pdf)
            print("✅ arXiv PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"arxiv:{type(e).__name__}")
            print(f"❌ arXiv failed: {e}")

    # 7) Crossref Direct Links - LAST RESORT BACKUP
    if doi:
        try:
            print("🔗 Trying Crossref direct links...")
            _try_fetch_crossref_links(doi, tmp_pdf)
            print("✅ Crossref PDF downloaded successfully!")
            tmp_pdf.rename(output_path)
            return True
        except Exception as e:
            tried.append(f"crossref:{type(e).__name__}")
            print(f"❌ Crossref direct failed: {e}")

    # Clean up temporary file
    try:
        tmp_pdf.unlink()
    except Exception:
        pass
    
    print(f"\n❌ All 7 optimized methods failed. Tried: {', '.join(tried)}")
    print("\n💡 Additional suggestions:")
    print("  • Try installing PyPaperBot: pip install PyPaperBot")
    print("  • Check if the paper is very recent (may not be indexed yet)")
    print("  • Try searching manually on Google Scholar")
    print("  • Contact your institution's library for access")
    return False

def interactive_doi_input() -> str:
    """Interactive terminal dialog to get DOI input"""
    print("=" * 60)
    print("🔬 PDF Fetcher - DOI to PDF Downloader")
    print("=" * 60)
    print()
    print("This tool will attempt to find and download a PDF for any given DOI.")
    print("It uses multiple sources including Open Access repositories, arXiv,")
    print("Semantic Scholar, and publisher websites.")
    print()
    
    while True:
        doi = input("📝 Enter DOI (e.g., 10.1038/nature12373): ").strip()
        
        if not doi:
            print("❌ Please enter a valid DOI.")
            continue
            
        # Basic DOI validation
        if not (doi.startswith("10.") or "doi.org" in doi.lower() or doi.lower().startswith("doi:")):
            print("⚠️  This doesn't look like a valid DOI. Continue anyway? (y/n): ", end="")
            if input().lower() not in ['y', 'yes']:
                continue
        
        return normalize_doi(doi)

def main():
    parser = argparse.ArgumentParser(description="Download PDF by DOI using comprehensive fallback methods")
    parser.add_argument("--doi", help="DOI to fetch (if not provided, will prompt interactively)")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), 
                       help=f"Output directory for downloaded PDFs (default: {DEFAULT_OUTPUT_DIR})")
    parser.add_argument("--filename", help="Custom filename for the PDF (without extension)")
    parser.add_argument("--install-deps", action="store_true", 
                       help="Install PyPaperBot and other optional dependencies")
    
    args = parser.parse_args()
    
    # Handle dependency installation
    if args.install_deps:
        print("🔧 Installing optional dependencies...")
        import subprocess
        deps = ["PyPaperBot", "beautifulsoup4", "requests"]
        for dep in deps:
            try:
                print(f"Installing {dep}...")
                subprocess.run([sys.executable, "-m", "pip", "install", dep], 
                             check=True, capture_output=True)
                print(f"✅ {dep} installed successfully")
            except subprocess.CalledProcessError as e:
                print(f"❌ Failed to install {dep}: {e}")
        print("🎉 Dependency installation complete!")
        return 0
    
    # Get DOI
    if args.doi:
        doi = normalize_doi(args.doi)
        print(f"🔬 Processing DOI: {doi}")
    else:
        doi = interactive_doi_input()
    
    # Setup output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate filename
    if args.filename:
        filename = f"{args.filename}.pdf"
    else:
        # Create safe filename from DOI
        safe_doi = doi.replace("/", "_").replace(".", "_")
        filename = f"{safe_doi}.pdf"
    
    output_path = output_dir / filename
    
    print(f"💾 Output will be saved to: {output_path}")
    print()
    
    # Attempt to download
    success = download_pdf_with_fallbacks(doi, output_path)
    
    if success:
        print()
        print("🎉 Success!")
        print(f"📁 PDF saved to: {output_path}")
        print(f"📊 File size: {output_path.stat().st_size / 1024:.1f} KB")
    else:
        print()
        print("😞 Failed to download PDF from any source.")
        print("This could be because:")
        print("  • The paper is behind a paywall")
        print("  • The DOI is invalid or not found")
        print("  • Network connectivity issues")
        print("  • The paper is not available in digital format")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())

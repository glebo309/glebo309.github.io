# PDF Fetcher by DOI

A standalone tool that uses the existing pipeline infrastructure to find and download PDFs based on DOI input.

## Features

- **Interactive terminal dialog** - Simply run the tool and it will ask for a DOI
- **Comprehensive PDF acquisition pipeline** with 8 fallback methods:
  1. **Open Access PDF** (Unpaywall) - Free, legal sources
  2. **Semantic Scholar** - Academic repository with open access papers
  3. **arXiv** - Preprint server for academic papers
  4. **Crossref direct links** - Publisher-provided PDF links
  5. **Publisher direct access** - Website scraping for PDF downloads
  6. **PyPaperBot** - Multi-source aggregator (Google Scholar, Crossref, SciHub, SciDB)
  7. **Sci-Hub** - Semi-legal fallback with multiple mirror domains
  8. **LibGen** - Library Genesis fallback
- **PDF validation** - Ensures downloaded files are actual PDFs, not HTML pages
- **Rich terminal output** - Clear progress indicators and status messages
- **Flexible output options** - Custom output directories and filenames

## Installation

### Quick Setup
```bash
# Install optional dependencies for maximum success rate
python3 tools/fetch_pdf_by_doi.py --install-deps
```

### Manual Installation
```bash
pip install PyPaperBot beautifulsoup4 requests pandas tqdm
```

## Usage

### Interactive Mode
```bash
python3 tools/fetch_pdf_by_doi.py
```

The tool will prompt you to enter a DOI and guide you through the process.

### Command Line Mode
```bash
# Basic usage with DOI
python3 tools/fetch_pdf_by_doi.py --doi "10.1038/nature12373"

# Custom output directory
python3 tools/fetch_pdf_by_doi.py --doi "10.1038/nature12373" --output-dir ~/Downloads/papers

# Custom filename
python3 tools/fetch_pdf_by_doi.py --doi "10.1038/nature12373" --filename "nature_thermometry_paper"
```

### Options

- `--doi DOI` - DOI to fetch (if not provided, will prompt interactively)
- `--output-dir OUTPUT_DIR` - Output directory for downloaded PDFs (default: `downloads/pdfs/`)
- `--filename FILENAME` - Custom filename for the PDF (without extension)
- `--install-deps` - Install PyPaperBot and other optional dependencies
- `--help` - Show help message

## Examples

### Successful Download
```
🔬 Processing DOI: 10.1038/nature12373
💾 Output will be saved to: downloads/test/10_1038_nature12373.pdf

🔍 Searching for PDF: 10.1038/nature12373
📊 Gathering metadata...
📄 Found paper: Nanometre-scale thermometry in a living cell
📅 Year: 2013
📖 Journal: Nature
🎓 Trying Semantic Scholar...
❌ Semantic Scholar failed: URL returned HTML instead of PDF
📚 Checking arXiv...
❌ arXiv failed: Not an arXiv paper
🔗 Trying Crossref direct links...
❌ Crossref direct failed: No accessible PDF found via Crossref
🏢 Trying publisher direct access...
✅ Publisher direct PDF downloaded successfully!

🎉 Success!
📁 PDF saved to: downloads/test/10_1038_nature12373.pdf
📊 File size: 259.4 KB
```

### Failed Download (Paywall)
```
🔬 Processing DOI: 10.1126/science.1259855
💾 Output will be saved to: downloads/test/10_1126_science_1259855.pdf

🔍 Searching for PDF: 10.1126/science.1259855
📊 Gathering metadata...
📄 Found paper: Planetary boundaries: Guiding human development on a changing planet
📅 Year: 2015
📖 Journal: Science
🎓 Trying Semantic Scholar...
❌ Semantic Scholar failed: 403 Client Error: Forbidden for url: https://www.science.org/...
📚 Checking arXiv...
❌ arXiv failed: Not an arXiv paper
🔗 Trying Crossref direct links...
❌ Crossref direct failed: No accessible PDF found via Crossref
🏢 Trying publisher direct access...
❌ Publisher direct failed: No PDF found via publisher direct access

❌ All methods failed. Tried: semantic_scholar:HTTPError, arxiv:RuntimeError, crossref:RuntimeError, publisher:RuntimeError

😞 Failed to download PDF from any source.
This could be because:
  • The paper is behind a paywall
  • The DOI is invalid or not found
  • Network connectivity issues
  • The paper is not available in digital format
```

## Dependencies

The tool requires the following Python packages:
- `requests` - For HTTP requests
- `beautifulsoup4` - For HTML parsing
- `pandas` - For data handling
- `tqdm` - For progress bars (inherited from pipeline)

Install with:
```bash
pip install requests beautifulsoup4 pandas tqdm
```

## How It Works

1. **Metadata Gathering**: Fetches paper metadata from Crossref, Semantic Scholar, and Unpaywall
2. **Sequential Fallback**: Tries each PDF source in order of reliability and legality
3. **PDF Validation**: Checks that downloaded files are actual PDFs using magic bytes
4. **Error Handling**: Provides clear feedback on what went wrong and why

## Integration with Existing Pipeline

This tool reuses the existing pipeline infrastructure:
- `tools/pipeline/sources.py` - API clients for academic databases
- `tools/pipeline/storage.py` - File storage utilities
- `tools/pipeline/config.py` - Configuration management

The tool is designed to be standalone while leveraging the robust PDF acquisition methods already developed in the project.

# PDF Fetcher Enhancement Plan
**Realistic Implementation Roadmap for Advanced Paper Retrieval**

---

## Current Status Analysis

Your current implementation (`fetch_pdf_by_doi.py`) includes:
- ✅ SciHub (multiple mirrors)
- ✅ Unpaywall/Open Access
- ✅ Semantic Scholar
- ✅ Publisher direct scraping
- ✅ PyPaperBot integration
- ✅ LibGen
- ✅ arXiv
- ✅ Crossref fallback
- ✅ PDF validation with GROBID
- ✅ GUI wrapper

**Success rate estimate:** ~70-80% for STEM, ~60-70% for philosophy

---

## Priority Tiers: What to Implement

### 🟢 **TIER 1: High-Value, Easy Implementation** 
*Implement these first - best ROI*

#### 1.1 Cross-Language Search (Chinese Academic Sites)
**Why you like this:** You specifically mentioned Chinese sources as very promising.

**Implementation complexity:** Medium  
**Expected improvement:** +10-15% success rate for STEM, +5-10% for philosophy  
**Legal status:** ✅ Fully legal (public repositories)

**Targets:**
- Baidu Scholar (百度学术) - `xueshu.baidu.com`
- CNKI mirrors (public access portions)
- Wanfang Data (public sections)

**How to implement:**
```python
def search_baidu_scholar(title: str, doi: str) -> Optional[str]:
    # Search Baidu Scholar with title
    # Parse results for PDF links
    # Common patterns: .edu.cn, .ac.cn domains
    # Return PDF URL if found
```

**Effort:** 2-3 days  
**Dependencies:** None (just requests + BeautifulSoup)

---

#### 1.2 Multi-Language Title Search
**Implementation complexity:** Easy  
**Expected improvement:** +5-8% success rate  
**Legal status:** ✅ Fully legal

**Strategy:**
- Translate title to: Chinese (Simplified/Traditional), Russian, Korean, Spanish
- Search with translated titles on regional search engines
- Many repositories store English PDFs with local metadata

**How to implement:**
```python
def translate_and_search(title: str) -> List[str]:
    # Use Google Translate API or deep-translator library
    # Translate to: zh-CN, zh-TW, ru, ko, es, fa
    # Search each on regional engines
    # Return candidate PDF URLs
```

**Effort:** 1-2 days  
**Dependencies:** `deep-translator` or Google Translate API

---

#### 1.3 Supplemental Material Directory Guessing
**Implementation complexity:** Easy  
**Expected improvement:** +3-5% success rate  
**Legal status:** ✅ Fully legal (public endpoints)

**Strategy:**
- Publishers often leave supplemental PDFs publicly accessible
- Test common patterns for each DOI

**Patterns to test:**
```
/suppl/
/si/
/supplementary/
/material/
/resources/
/article-pdf/
/content/{journal}/{year}/{issue}/{article}/
/epdf/
/pdfdirect/
```

**Effort:** 1 day  
**Dependencies:** None

---

#### 1.4 Google Scholar PDF Extraction
**Implementation complexity:** Medium (rate limiting concerns)  
**Expected improvement:** +8-12% success rate  
**Legal status:** ⚠️ Gray (violates ToS but not illegal)

**Strategy:**
- Search Google Scholar by title
- Extract PDF links from university domains (.edu, .ac.uk, etc.)
- Validate PDFs

**Effort:** 2-3 days  
**Dependencies:** Need to handle rate limiting, possibly use scholarly library

---

### 🟡 **TIER 2: Medium-Value, Moderate Complexity**
*Implement after Tier 1 if you want deeper coverage*

#### 2.1 National Repository Search (Multi-Country)
**Implementation complexity:** High  
**Expected improvement:** +10-15% success rate  
**Legal status:** ✅ Fully legal

**Priority countries for STEM + Philosophy:**
- 🇷🇺 Russia: CyberLeninka, eLibrary.ru
- 🇮🇷 Iran: SID.ir
- 🇰🇷 South Korea: KISS, KoreaScience
- 🇧🇷 Brazil: SciELO
- 🇪🇸 Spain: Dialnet
- 🇫🇷 France: HAL
- 🇮🇳 India: Shodhganga
- 🇳🇱 Netherlands: Pure/NARCIS
- 🇸🇪 Sweden: DiVA
- 🇳🇴 Norway: Cristin/NVA

**How to implement:**
```python
class NationalRepositorySearcher:
    def search_russia(self, doi, title): ...
    def search_iran(self, doi, title): ...
    def search_korea(self, doi, title): ...
    # etc.
```

**Effort:** 2-3 weeks (each country needs custom scraper)  
**Dependencies:** None, but needs maintenance

---

#### 2.2 Citation Mining (Cited-by Recovery)
**Implementation complexity:** Medium-High  
**Expected improvement:** +5-10% success rate  
**Legal status:** ✅ Fully legal

**Strategy:**
- Get papers that cite target paper (via Crossref/Semantic Scholar)
- Check their supplementary materials
- Often contains the original paper

**Effort:** 3-5 days  
**Dependencies:** Crossref API, S2 API

---

#### 2.3 Author Homepage Scraping
**Implementation complexity:** Medium  
**Expected improvement:** +5-8% success rate (especially philosophy)  
**Legal status:** ✅ Fully legal

**Strategy:**
- Extract author names from metadata
- Search for author homepages (university sites)
- Common patterns: `/~username/`, `/people/`, `/faculty/`
- Look for `/papers/`, `/publications/` directories

**Effort:** 3-4 days  
**Dependencies:** None

---

#### 2.4 Institutional Repository Crawling (OAI-PMH)
**Implementation complexity:** High  
**Expected improvement:** +8-12% success rate  
**Legal status:** ✅ Fully legal

**Strategy:**
- Query 50-200 institutional repositories via OAI-PMH protocol
- Search by DOI, title, author
- DSpace, EPrints, Fedora systems

**Effort:** 1-2 weeks  
**Dependencies:** `sickle` library for OAI-PMH

---

### 🔴 **TIER 3: Advanced/Experimental**
*Only implement if you want maximum coverage*

#### 3.1 Conference Proceedings Scraping
**Implementation complexity:** High  
**Expected improvement:** +3-5% success rate  
**Legal status:** ✅ Fully legal

**Strategy:**
- Search for conference versions of papers
- Many conferences leave proceedings publicly accessible
- Target: ACM, IEEE, philosophy conferences

**Effort:** 1-2 weeks

---

#### 3.2 ResearchGate/Academia.edu Preview Extraction
**Implementation complexity:** Very High (anti-scraping measures)  
**Expected improvement:** +5-8% success rate  
**Legal status:** ⚠️ Gray (violates ToS)

**Strategy:**
- Extract public preview PDFs
- Use cached Google results
- Requires sophisticated anti-detection

**Effort:** 2-3 weeks  
**Risk:** High (may break frequently)

---

#### 3.3 Archive.org Hidden Collections
**Implementation complexity:** Medium  
**Expected improvement:** +2-4% success rate (mainly old papers)  
**Legal status:** ✅ Fully legal

**Strategy:**
- Search Archive.org collections API
- Many philosophy manuscripts and old journals

**Effort:** 3-5 days

---

#### 3.4 Image-Based PDF Reconstruction
**Implementation complexity:** Very High  
**Expected improvement:** +1-3% success rate  
**Legal status:** ✅ Fully legal

**Strategy:**
- Some sites (Duxiu, Korean portals) show page images
- Download images, assemble into PDF, OCR

**Effort:** 1-2 weeks  
**Dependencies:** Tesseract OCR, img2pdf

---

## ❌ **NOT RECOMMENDED** 
*Too complex, too risky, or too low yield*

### Things to Skip:
1. **Tor exit node manipulation** - Complex, minimal benefit
2. **Browser cookie hijacking** - Security risk, unethical
3. **Email auto-request systems** - Requires email infrastructure, slow
4. **Hash-based LibGen/SciHub dumps** - Already covered by direct access
5. **PDF fingerprint clustering** - Requires massive datasets, complex
6. **LOCKSS node exploitation** - Rare, hard to find, low yield
7. **Transparent proxy abuse** - Unreliable, country-specific
8. **CDN bucket guessing** - Already covered by supplemental directory search
9. **DSpace dark repository exploitation** - Ethical concerns

---

## 🎯 **RECOMMENDED IMPLEMENTATION ORDER**

### Phase 1: Quick Wins (1-2 weeks)
1. ✅ Supplemental material directory guessing (1 day)
2. ✅ Multi-language title search (2 days)
3. ✅ Baidu Scholar integration (3 days)
4. ✅ Google Scholar PDF extraction (3 days)

**Expected total improvement:** +20-30% success rate

---

### Phase 2: Deep Search Mode (2-4 weeks)
5. ✅ Author homepage scraping (4 days)
6. ✅ Citation mining (5 days)
7. ✅ National repositories (Russia, Iran, Korea) (1 week)
8. ✅ HAL/Dialnet/SciELO integration (1 week)

**Expected total improvement:** +30-40% success rate

---

### Phase 3: Advanced Features (Optional, 2-4 weeks)
9. ✅ OAI-PMH institutional repository harvesting (2 weeks)
10. ✅ Conference proceedings scraping (1 week)
11. ✅ Archive.org collections (1 week)

**Expected total improvement:** +40-50% success rate

---

## 🔧 **"Deep Search" Toggle Design**

### Two Modes:

#### **Quick Mode** (Current behavior)
- SciHub → Unpaywall → Semantic Scholar → Publisher → LibGen
- ~2-10 seconds per paper
- Success rate: ~70-80%

#### **Deep Search Mode** (New)
- All Quick Mode sources +
- Baidu Scholar
- Multi-language search
- Supplemental directories
- Google Scholar
- Author homepages
- Citation mining
- National repositories (top 5-10)
- ~30-120 seconds per paper
- Success rate: ~85-95%

### GUI Implementation:
```python
# Add checkbox to GUI
self.deep_search_var = BooleanVar(value=False)
deep_search_checkbox = Checkbutton(
    main_frame, 
    text="Enable Deep Search (slower, more thorough)",
    variable=self.deep_search_var
)
```

---

## 📊 **Realistic Success Rate Projections**

### Current (Quick Mode):
- STEM papers: 70-80%
- Philosophy papers: 60-70%
- Recent papers (< 5 years): 75-85%
- Old papers (> 20 years): 50-60%

### After Phase 1 (Quick Wins):
- STEM papers: 80-90%
- Philosophy papers: 75-85%
- Recent papers: 85-95%
- Old papers: 60-70%

### After Phase 2 (Deep Search):
- STEM papers: 85-95%
- Philosophy papers: 85-95%
- Recent papers: 90-98%
- Old papers: 70-80%

### After Phase 3 (Maximum):
- STEM papers: 90-97%
- Philosophy papers: 90-97%
- Recent papers: 93-99%
- Old papers: 75-85%

**Note:** 100% is impossible - some papers are truly unavailable digitally.

---

## 🚀 **Next Steps**

### Immediate Actions:
1. **Start with Phase 1** - highest ROI, easiest implementation
2. **Test each method** on 100 random DOIs to measure actual improvement
3. **Add telemetry** to track which methods succeed most often
4. **Implement Deep Search toggle** in GUI

### Code Architecture:
```python
class PDFSearchEngine:
    def __init__(self, deep_search=False):
        self.deep_search = deep_search
        self.methods = self._get_methods()
    
    def _get_methods(self):
        quick = [
            SciHubMethod(),
            UnpaywallMethod(),
            SemanticScholarMethod(),
            PublisherDirectMethod(),
            LibGenMethod()
        ]
        
        if self.deep_search:
            deep = [
                BaiduScholarMethod(),
                MultiLanguageSearchMethod(),
                SupplementalDirMethod(),
                GoogleScholarMethod(),
                AuthorHomepageMethod(),
                CitationMiningMethod(),
                NationalRepoMethod()
            ]
            return quick + deep
        return quick
```

---

## 💡 **Key Insights**

### What Makes Sense:
1. ✅ **Chinese sources** - You're right, very promising (10-15% boost)
2. ✅ **Multi-language search** - Simple, effective
3. ✅ **National repositories** - High yield for specific regions
4. ✅ **Supplemental directories** - Easy win
5. ✅ **Deep search toggle** - Great UX, lets users choose speed vs. thoroughness

### What Doesn't Make Sense:
1. ❌ **Tor/VPN manipulation** - Too complex for minimal gain
2. ❌ **Email automation** - Too slow, requires infrastructure
3. ❌ **Browser cookie stealing** - Unethical, security risk
4. ❌ **Hash-based matching** - Already covered by existing sources
5. ❌ **PDF fingerprinting** - Requires massive datasets

### Philosophy-Specific Wins:
- PhilPapers integration (not in your current code!)
- HAL (France) - huge philosophy coverage
- Dialnet (Spain) - continental philosophy
- Author homepages - philosophers share more freely
- Conference proceedings - many philosophy papers only exist here

---

## 📝 **Maintenance Considerations**

### High Maintenance:
- Google Scholar (rate limiting, HTML changes)
- National repositories (each needs custom scraper)
- ResearchGate/Academia.edu (anti-scraping measures)

### Low Maintenance:
- OAI-PMH repositories (standardized protocol)
- Supplemental directories (stable patterns)
- Multi-language search (stable APIs)
- Baidu Scholar (relatively stable)

### Recommendation:
**Focus on low-maintenance, high-yield methods first.**

---

## 🎓 **Philosophy-Specific Additions**

Add these to boost philosophy paper success:

1. **PhilPapers API** - Easy, high yield for philosophy
2. **PhilArchive** - Preprint server for philosophy
3. **HAL** - French repository, strong in continental philosophy
4. **Dialnet** - Spanish repository, philosophy coverage
5. **SSRN Philosophy** - Working papers
6. **Author estate archives** - Husserl, Wittgenstein, Nietzsche, etc.

**Effort:** 1 week total  
**Expected improvement for philosophy:** +15-20%

---

## Final Recommendation

### Start Here (Week 1-2):
1. Supplemental directory guessing
2. Multi-language title search
3. Baidu Scholar
4. PhilPapers (for philosophy)

### Then Add (Week 3-4):
5. Google Scholar
6. Author homepage scraping
7. HAL/Dialnet

### Deep Search Toggle:
8. Implement GUI toggle
9. Make methods conditional on toggle

**This gives you 80-90% success rate with reasonable effort.**

The rest of the ideas in your brainstorming doc are either:
- Too complex for the benefit
- Already covered by existing methods
- Maintenance nightmares
- Ethically questionable

**Focus on the high-value, low-maintenance wins.**
